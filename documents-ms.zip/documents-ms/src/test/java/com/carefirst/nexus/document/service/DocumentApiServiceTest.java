package com.carefirst.nexus.document.service;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.carefirst.nexus.document.gen.model.AddDocumentResponse;
import com.carefirst.nexus.document.gen.model.ContractDocument;
import com.carefirst.nexus.document.gen.model.ContractDocumentResponse;
import com.carefirst.nexus.document.gen.model.ContractSearchCriteria;
import com.carefirst.nexus.document.gen.model.DocumentDetails;
import com.carefirst.nexus.document.gen.model.DocumentProperty;
import com.carefirst.nexus.document.gen.model.DocumentRequest;
import com.carefirst.nexus.document.gen.model.DocumentResponse;
import com.carefirst.nexus.document.gen.model.SearchDocumentResponse;
import com.carefirst.nexus.utils.web.error.AppJSONException;

public class DocumentApiServiceTest {
	
	@InjectMocks
	private DocumentApiService documentApiService;
	
	@Mock
	EDMSService edmsService;
	
	ResponseEntity<?> responseEntity;
	
	AddDocumentResponse addDocumentResponse;
	
	ContractDocumentResponse contractDocumentResponse;
	
	SearchDocumentResponse searchDocumentResponse;
	
	DocumentResponse documentResponse;
	
	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		addDocumentResponse = new AddDocumentResponse();
		documentResponse = new DocumentResponse();
		DocumentDetails documentDetails = new DocumentDetails();
		documentResponse.setDocument(documentDetails);
		contractDocumentResponse = new ContractDocumentResponse();
		List<ContractDocument> documentProperties = new ArrayList<>();
		contractDocumentResponse.setDocumentProperties(documentProperties);
		responseEntity = new ResponseEntity<>(addDocumentResponse, HttpStatus.OK);
		List<DocumentProperty> properties = new ArrayList<>();
		searchDocumentResponse = new SearchDocumentResponse();
		searchDocumentResponse.setDocumentProperties(properties);
	}
	
	@Test
	public void testAddDocument() {
		DocumentRequest documentRequest = new DocumentRequest();
		documentRequest.setDocumentClass("MedicalRecord");
		documentRequest.setDocumentData("test".getBytes());
		documentRequest.setDocumentProperty("");
		assertEquals(documentApiService.addDocument(documentRequest), responseEntity);
	}
	
	@Test
	public void testGetDocument() {
		responseEntity = new ResponseEntity<>(documentResponse, HttpStatus.OK);
		assertEquals(documentApiService.getDocument("232EF-3232ouee-12"), responseEntity);
	}
	
	@Test
	public void testFindContractDocuments() {
		responseEntity = new ResponseEntity<>(contractDocumentResponse, HttpStatus.OK);
		List<String> documentClass = new ArrayList<>();
		ContractSearchCriteria contractSearchCriteria = new ContractSearchCriteria();
		assertEquals(documentApiService.findContractDocuments(LocalDate.now(), LocalDate.now(), documentClass, contractSearchCriteria), responseEntity);
	}
	
	@Test
	public void testFindDocuments() {
		responseEntity = new ResponseEntity<>(searchDocumentResponse, HttpStatus.OK);
		List<String> documentClass = new ArrayList<>();
		List<DocumentProperty> searchCriteria = new ArrayList<>();
		assertEquals(documentApiService.findDocuments(LocalDate.now(), LocalDate.now(), documentClass, true, searchCriteria), responseEntity);
	}
	
	@Test(expected = AppJSONException.class)
	public void testAddDocumentException() {
		DocumentRequest documentRequest = new DocumentRequest();
		documentRequest.setDocumentClass("MedicalRecord");
		documentRequest.setDocumentData("test".getBytes());
		documentRequest.setDocumentProperty("");
		documentApiService.addDocument(documentRequest);
	}
	
	@Test(expected = AppJSONException.class)
	public void testGetDocumentException() {
		when(documentApiService.getDocument(any())).thenThrow(AppJSONException.class);
		documentApiService.getDocument("232EF-3232ouee-12");
	}
	
	@Test(expected = AppJSONException.class)
	public void testFindContractDocumentsException() {
		responseEntity = new ResponseEntity<>(contractDocumentResponse, HttpStatus.OK);
		List<String> documentClass = new ArrayList<>();
		ContractSearchCriteria contractSearchCriteria = new ContractSearchCriteria();
		documentApiService.findContractDocuments(LocalDate.now(), LocalDate.now(), documentClass, contractSearchCriteria);
	}

	@Test(expected = AppJSONException.class)
	public void testFindDocumentsException() {
		responseEntity = new ResponseEntity<>(searchDocumentResponse, HttpStatus.OK);
		List<String> documentClass = new ArrayList<>();
		List<DocumentProperty> searchCriteria = new ArrayList<>();
		documentApiService.findDocuments(LocalDate.now(), LocalDate.now(), documentClass, true, searchCriteria);
	}
}
