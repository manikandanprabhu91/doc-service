package com.carefirst.nexus.document.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest.Body;
import com.carefirst.enterprise.dms.searchschema.Classes;
import com.carefirst.enterprise.dms.searchschema.SearchDocRequest;
import com.carefirst.enterprise.dms.searchschema.SearchDocResponse;
import com.carefirst.enterprise.dms.getdocschema.GetDocResponse;
import com.carefirst.enterprise.dms.searchcontractschema.SearchContractRequest;

/**
 * 
 * @author aad7740
 *
 */
public class EDMSServiceTest {

	@Mock
	EDMSService edmsService;

	GetDocResponse docResponse;

	SearchDocResponse searchDocResponse;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		docResponse = new GetDocResponse();
		searchDocResponse = new SearchDocResponse();
	}

	@Test
	public void testEDMSGetDocument() {
		GetDocRequest request = new GetDocRequest();
		Body body = new Body();
		body.setGuid("3091EF6F-0100-CF3E-87B8-A8E0A054E45B");
		request.setBody(body);
		GetDocResponse docResponse = edmsService.getDocument(request);
		assertEquals(docResponse, docResponse);
	}
	
	@Test
	public void testSearchContract() {
		SearchContractRequest contractRequest = new SearchContractRequest();
		assertNull(edmsService.searchContract(contractRequest));
	}

	@Test
	public void testSearchDocument() throws Exception {
		SearchDocRequest request = new SearchDocRequest();
		com.carefirst.enterprise.dms.searchschema.SearchDocRequest.Body value = new com.carefirst.enterprise.dms.searchschema.SearchDocRequest.Body();
		Classes classes = new Classes();
		value.setClasses(classes);
		com.carefirst.enterprise.dms.searchschema.Criteria criteria = new com.carefirst.enterprise.dms.searchschema.Criteria(); 
		value.setCriteria(criteria);
		value.setFromDate(String.valueOf("11/10/2019"));
		value.setToDate(String.valueOf("01/01/2019"));
		value.setVersionHistory(true);
		request.setBody(value);
		assertNull(edmsService.searchDocument(request));
	}

//	@Test(expected=Exception.class)
//	public void testEDMSGetDocumentException() {
//		GetDocRequest request = new GetDocRequest();
//		Body body = new Body();
//		body.setGuid("3091EF6F-0100-CF3E-87B8-A8E0A054E45B");
//		request.setBody(body);
//		edmsService.getDocument(request);
//	}	
//
//	@Test(expected=Exception.class)
//	public void testSearchContractException() {
//		SearchContractRequest contractRequest = new SearchContractRequest();
//		edmsService.searchContract(contractRequest);
//	}
//
//	
//	@Test(expected=Exception.class)
//	public void testSearchDocumentException() throws Exception {
//		SearchDocRequest request = new SearchDocRequest();
//		com.carefirst.enterprise.dms.searchschema.SearchDocRequest.Body value = new com.carefirst.enterprise.dms.searchschema.SearchDocRequest.Body();
//		Classes classes = new Classes();
//		value.setClasses(classes);
//		com.carefirst.enterprise.dms.searchschema.Criteria criteria = new com.carefirst.enterprise.dms.searchschema.Criteria(); 
//		value.setCriteria(criteria);
//		value.setFromDate(String.valueOf("11/10/2019"));
//		value.setToDate(String.valueOf("01/01/2019"));
//		value.setVersionHistory(true);
//		request.setBody(value);
//		edmsService.searchDocument(request);
//	}

}
