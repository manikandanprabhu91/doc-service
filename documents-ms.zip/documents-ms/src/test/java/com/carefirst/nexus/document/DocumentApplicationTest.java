package com.carefirst.nexus.document;

import static org.junit.Assert.assertTrue;

import org.junit.Test;


public class DocumentApplicationTest {

	@Test
	public void healthCheck() {
		DocumentApplication app = new DocumentApplication();
		assertTrue("OK".equals(app.healthCheck()));
	}
	
}
