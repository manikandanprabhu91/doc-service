package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.carefirst.nexus.document.gen.model.ContractDocument;
import com.carefirst.nexus.document.gen.model.ContractIdentifier;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ContractDocumentResponse
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-26T11:36:03.601-04:00[America/New_York]")

public class ContractDocumentResponse   {
  @JsonProperty("responseContext")
  private com.carefirst.nexus.utils.web.model.ResponseContext responseContext;

  @JsonProperty("contractIdentifier")
  private ContractIdentifier contractIdentifier;

  @JsonProperty("documentProperties")
  @Valid
  private List<ContractDocument> documentProperties = null;

  public ContractDocumentResponse responseContext(com.carefirst.nexus.utils.web.model.ResponseContext responseContext) {
    this.responseContext = responseContext;
    return this;
  }

  /**
   * Get responseContext
   * @return responseContext
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public com.carefirst.nexus.utils.web.model.ResponseContext getResponseContext() {
    return responseContext;
  }

  public void setResponseContext(com.carefirst.nexus.utils.web.model.ResponseContext responseContext) {
    this.responseContext = responseContext;
  }

  public ContractDocumentResponse contractIdentifier(ContractIdentifier contractIdentifier) {
    this.contractIdentifier = contractIdentifier;
    return this;
  }

  /**
   * Get contractIdentifier
   * @return contractIdentifier
  */
  @ApiModelProperty(value = "")

  @Valid

  public ContractIdentifier getContractIdentifier() {
    return contractIdentifier;
  }

  public void setContractIdentifier(ContractIdentifier contractIdentifier) {
    this.contractIdentifier = contractIdentifier;
  }

  public ContractDocumentResponse documentProperties(List<ContractDocument> documentProperties) {
    this.documentProperties = documentProperties;
    return this;
  }

  public ContractDocumentResponse addDocumentPropertiesItem(ContractDocument documentPropertiesItem) {
    if (this.documentProperties == null) {
      this.documentProperties = new ArrayList<>();
    }
    this.documentProperties.add(documentPropertiesItem);
    return this;
  }

  /**
   * Get documentProperties
   * @return documentProperties
  */
  @ApiModelProperty(value = "")

  @Valid

  public List<ContractDocument> getDocumentProperties() {
    return documentProperties;
  }

  public void setDocumentProperties(List<ContractDocument> documentProperties) {
    this.documentProperties = documentProperties;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContractDocumentResponse contractDocumentResponse = (ContractDocumentResponse) o;
    return Objects.equals(this.responseContext, contractDocumentResponse.responseContext) &&
        Objects.equals(this.contractIdentifier, contractDocumentResponse.contractIdentifier) &&
        Objects.equals(this.documentProperties, contractDocumentResponse.documentProperties);
  }

  @Override
  public int hashCode() {
    return Objects.hash(responseContext, contractIdentifier, documentProperties);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContractDocumentResponse {\n");
    
    sb.append("    responseContext: ").append(toIndentedString(responseContext)).append("\n");
    sb.append("    contractIdentifier: ").append(toIndentedString(contractIdentifier)).append("\n");
    sb.append("    documentProperties: ").append(toIndentedString(documentProperties)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

