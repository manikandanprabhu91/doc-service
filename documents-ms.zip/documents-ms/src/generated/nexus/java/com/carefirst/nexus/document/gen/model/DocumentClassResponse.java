package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * DocumentClassResponse
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-26T11:36:03.601-04:00[America/New_York]")

public class DocumentClassResponse   {
  @JsonProperty("responseContext")
  private com.carefirst.nexus.utils.web.model.ResponseContext responseContext;

  @JsonProperty("documentSubClasses")
  @Valid
  private List<String> documentSubClasses = null;

  public DocumentClassResponse responseContext(com.carefirst.nexus.utils.web.model.ResponseContext responseContext) {
    this.responseContext = responseContext;
    return this;
  }

  /**
   * Get responseContext
   * @return responseContext
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public com.carefirst.nexus.utils.web.model.ResponseContext getResponseContext() {
    return responseContext;
  }

  public void setResponseContext(com.carefirst.nexus.utils.web.model.ResponseContext responseContext) {
    this.responseContext = responseContext;
  }

  public DocumentClassResponse documentSubClasses(List<String> documentSubClasses) {
    this.documentSubClasses = documentSubClasses;
    return this;
  }

  public DocumentClassResponse addDocumentSubClassesItem(String documentSubClassesItem) {
    if (this.documentSubClasses == null) {
      this.documentSubClasses = new ArrayList<>();
    }
    this.documentSubClasses.add(documentSubClassesItem);
    return this;
  }

  /**
   * Get documentSubClasses
   * @return documentSubClasses
  */
  @ApiModelProperty(value = "")


  public List<String> getDocumentSubClasses() {
    return documentSubClasses;
  }

  public void setDocumentSubClasses(List<String> documentSubClasses) {
    this.documentSubClasses = documentSubClasses;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DocumentClassResponse documentClassResponse = (DocumentClassResponse) o;
    return Objects.equals(this.responseContext, documentClassResponse.responseContext) &&
        Objects.equals(this.documentSubClasses, documentClassResponse.documentSubClasses);
  }

  @Override
  public int hashCode() {
    return Objects.hash(responseContext, documentSubClasses);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DocumentClassResponse {\n");
    
    sb.append("    responseContext: ").append(toIndentedString(responseContext)).append("\n");
    sb.append("    documentSubClasses: ").append(toIndentedString(documentSubClasses)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

