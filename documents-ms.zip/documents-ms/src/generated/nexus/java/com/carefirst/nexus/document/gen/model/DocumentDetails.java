package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * DocumentDetails
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-26T11:36:03.601-04:00[America/New_York]")

public class DocumentDetails   {
  @JsonProperty("documentId")
  private String documentId;

  @JsonProperty("documentTitle")
  private String documentTitle;

  @JsonProperty("documentMimeType")
  private String documentMimeType;

  @JsonProperty("documentData")
  private byte[] documentData;

  public DocumentDetails documentId(String documentId) {
    this.documentId = documentId;
    return this;
  }

  /**
   * document id
   * @return documentId
  */
  @ApiModelProperty(example = "3091EF6F-0100-CF3E-87B8-A8E0A054E45B", required = true, value = "document id")
  @NotNull


  public String getDocumentId() {
    return documentId;
  }

  public void setDocumentId(String documentId) {
    this.documentId = documentId;
  }

  public DocumentDetails documentTitle(String documentTitle) {
    this.documentTitle = documentTitle;
    return this;
  }

  /**
   * Get documentTitle
   * @return documentTitle
  */
  @ApiModelProperty(value = "")


  public String getDocumentTitle() {
    return documentTitle;
  }

  public void setDocumentTitle(String documentTitle) {
    this.documentTitle = documentTitle;
  }

  public DocumentDetails documentMimeType(String documentMimeType) {
    this.documentMimeType = documentMimeType;
    return this;
  }

  /**
   * Get documentMimeType
   * @return documentMimeType
  */
  @ApiModelProperty(example = "application/pdf", value = "")


  public String getDocumentMimeType() {
    return documentMimeType;
  }

  public void setDocumentMimeType(String documentMimeType) {
    this.documentMimeType = documentMimeType;
  }

  public DocumentDetails documentData(byte[] documentData) {
    this.documentData = documentData;
    return this;
  }

  /**
   * Get documentData
   * @return documentData
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public byte[] getDocumentData() {
    return documentData;
  }

  public void setDocumentData(byte[] documentData) {
    this.documentData = documentData;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DocumentDetails documentDetails = (DocumentDetails) o;
    return Objects.equals(this.documentId, documentDetails.documentId) &&
        Objects.equals(this.documentTitle, documentDetails.documentTitle) &&
        Objects.equals(this.documentMimeType, documentDetails.documentMimeType) &&
        Objects.equals(this.documentData, documentDetails.documentData);
  }

  @Override
  public int hashCode() {
    return Objects.hash(documentId, documentTitle, documentMimeType, documentData);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DocumentDetails {\n");
    
    sb.append("    documentId: ").append(toIndentedString(documentId)).append("\n");
    sb.append("    documentTitle: ").append(toIndentedString(documentTitle)).append("\n");
    sb.append("    documentMimeType: ").append(toIndentedString(documentMimeType)).append("\n");
    sb.append("    documentData: ").append(toIndentedString(documentData)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

