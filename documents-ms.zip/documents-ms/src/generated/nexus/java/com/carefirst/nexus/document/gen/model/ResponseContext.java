package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.carefirst.nexus.document.gen.model.Error;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.OffsetDateTime;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ResponseContext
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-25T17:57:50.773-04:00[America/New_York]")

public class ResponseContext   {
  @JsonProperty("status")
  private String status;

  @JsonProperty("success")
  private Boolean success;

  @JsonProperty("guid")
  private String guid;

  @JsonProperty("responseTime")
  private String responseTime;

  @JsonProperty("currentTimeStamp")
  @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE_TIME)
  private OffsetDateTime currentTimeStamp;

  @JsonProperty("error")
  private Error error;

  public ResponseContext status(String status) {
    this.status = status;
    return this;
  }

  /**
   * status of the request
   * @return status
  */
  @ApiModelProperty(example = "200 OK", required = true, value = "status of the request")
  @NotNull


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public ResponseContext success(Boolean success) {
    this.success = success;
    return this;
  }

  /**
   * Get success
   * @return success
  */
  @ApiModelProperty(example = "true", required = true, value = "")
  @NotNull


  public Boolean getSuccess() {
    return success;
  }

  public void setSuccess(Boolean success) {
    this.success = success;
  }

  public ResponseContext guid(String guid) {
    this.guid = guid;
    return this;
  }

  /**
   * GUID for the tracking request / Auditable purpose
   * @return guid
  */
  @ApiModelProperty(example = "08b4b150-ca44-47d8-9c4a-a87979357f35", required = true, value = "GUID for the tracking request / Auditable purpose")
  @NotNull


  public String getGuid() {
    return guid;
  }

  public void setGuid(String guid) {
    this.guid = guid;
  }

  public ResponseContext responseTime(String responseTime) {
    this.responseTime = responseTime;
    return this;
  }

  /**
   * Get responseTime
   * @return responseTime
  */
  @ApiModelProperty(example = "121 ms", required = true, value = "")
  @NotNull


  public String getResponseTime() {
    return responseTime;
  }

  public void setResponseTime(String responseTime) {
    this.responseTime = responseTime;
  }

  public ResponseContext currentTimeStamp(OffsetDateTime currentTimeStamp) {
    this.currentTimeStamp = currentTimeStamp;
    return this;
  }

  /**
   * Get currentTimeStamp
   * @return currentTimeStamp
  */
  @ApiModelProperty(example = "2019-06-10T04:55:13.309-04:00", required = true, value = "")
  @NotNull

  @Valid

  public OffsetDateTime getCurrentTimeStamp() {
    return currentTimeStamp;
  }

  public void setCurrentTimeStamp(OffsetDateTime currentTimeStamp) {
    this.currentTimeStamp = currentTimeStamp;
  }

  public ResponseContext error(Error error) {
    this.error = error;
    return this;
  }

  /**
   * Get error
   * @return error
  */
  @ApiModelProperty(value = "")

  @Valid

  public Error getError() {
    return error;
  }

  public void setError(Error error) {
    this.error = error;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ResponseContext responseContext = (ResponseContext) o;
    return Objects.equals(this.status, responseContext.status) &&
        Objects.equals(this.success, responseContext.success) &&
        Objects.equals(this.guid, responseContext.guid) &&
        Objects.equals(this.responseTime, responseContext.responseTime) &&
        Objects.equals(this.currentTimeStamp, responseContext.currentTimeStamp) &&
        Objects.equals(this.error, responseContext.error);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, success, guid, responseTime, currentTimeStamp, error);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ResponseContext {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    success: ").append(toIndentedString(success)).append("\n");
    sb.append("    guid: ").append(toIndentedString(guid)).append("\n");
    sb.append("    responseTime: ").append(toIndentedString(responseTime)).append("\n");
    sb.append("    currentTimeStamp: ").append(toIndentedString(currentTimeStamp)).append("\n");
    sb.append("    error: ").append(toIndentedString(error)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

