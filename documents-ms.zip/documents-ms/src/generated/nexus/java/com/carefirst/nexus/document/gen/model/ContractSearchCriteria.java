package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.carefirst.nexus.document.gen.model.ContractGroupProductSearchCriteria;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ContractSearchCriteria
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-26T11:36:03.601-04:00[America/New_York]")

public class ContractSearchCriteria   {
  @JsonProperty("subscriberId")
  private String subscriberId;

  @JsonProperty("memberSuffix")
  private String memberSuffix;

  @JsonProperty("current")
  private Long current;

  @JsonProperty("version")
  private String version;

  @JsonProperty("groupProductCriteria")
  @Valid
  private List<ContractGroupProductSearchCriteria> groupProductCriteria = null;

  public ContractSearchCriteria subscriberId(String subscriberId) {
    this.subscriberId = subscriberId;
    return this;
  }

  /**
   * subscriber id
   * @return subscriberId
  */
  @ApiModelProperty(example = "9013456077", value = "subscriber id")


  public String getSubscriberId() {
    return subscriberId;
  }

  public void setSubscriberId(String subscriberId) {
    this.subscriberId = subscriberId;
  }

  public ContractSearchCriteria memberSuffix(String memberSuffix) {
    this.memberSuffix = memberSuffix;
    return this;
  }

  /**
   * member suffix
   * @return memberSuffix
  */
  @ApiModelProperty(example = "01", value = "member suffix")


  public String getMemberSuffix() {
    return memberSuffix;
  }

  public void setMemberSuffix(String memberSuffix) {
    this.memberSuffix = memberSuffix;
  }

  public ContractSearchCriteria current(Long current) {
    this.current = current;
    return this;
  }

  /**
   * Get current
   * @return current
  */
  @ApiModelProperty(value = "")


  public Long getCurrent() {
    return current;
  }

  public void setCurrent(Long current) {
    this.current = current;
  }

  public ContractSearchCriteria version(String version) {
    this.version = version;
    return this;
  }

  /**
   * version indicator
   * @return version
  */
  @ApiModelProperty(example = "01", value = "version indicator")


  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public ContractSearchCriteria groupProductCriteria(List<ContractGroupProductSearchCriteria> groupProductCriteria) {
    this.groupProductCriteria = groupProductCriteria;
    return this;
  }

  public ContractSearchCriteria addGroupProductCriteriaItem(ContractGroupProductSearchCriteria groupProductCriteriaItem) {
    if (this.groupProductCriteria == null) {
      this.groupProductCriteria = new ArrayList<>();
    }
    this.groupProductCriteria.add(groupProductCriteriaItem);
    return this;
  }

  /**
   * Get groupProductCriteria
   * @return groupProductCriteria
  */
  @ApiModelProperty(value = "")

  @Valid

  public List<ContractGroupProductSearchCriteria> getGroupProductCriteria() {
    return groupProductCriteria;
  }

  public void setGroupProductCriteria(List<ContractGroupProductSearchCriteria> groupProductCriteria) {
    this.groupProductCriteria = groupProductCriteria;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContractSearchCriteria contractSearchCriteria = (ContractSearchCriteria) o;
    return Objects.equals(this.subscriberId, contractSearchCriteria.subscriberId) &&
        Objects.equals(this.memberSuffix, contractSearchCriteria.memberSuffix) &&
        Objects.equals(this.current, contractSearchCriteria.current) &&
        Objects.equals(this.version, contractSearchCriteria.version) &&
        Objects.equals(this.groupProductCriteria, contractSearchCriteria.groupProductCriteria);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subscriberId, memberSuffix, current, version, groupProductCriteria);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContractSearchCriteria {\n");
    
    sb.append("    subscriberId: ").append(toIndentedString(subscriberId)).append("\n");
    sb.append("    memberSuffix: ").append(toIndentedString(memberSuffix)).append("\n");
    sb.append("    current: ").append(toIndentedString(current)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    groupProductCriteria: ").append(toIndentedString(groupProductCriteria)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

