package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.carefirst.nexus.document.gen.model.DocumentProperty;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.ArrayList;
import java.util.List;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * SearchDocumentResponse
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-26T11:36:03.601-04:00[America/New_York]")

public class SearchDocumentResponse   {
  @JsonProperty("responseContext")
  private com.carefirst.nexus.utils.web.model.ResponseContext responseContext;

  @JsonProperty("documentProperties")
  @Valid
  private List<DocumentProperty> documentProperties = null;

  public SearchDocumentResponse responseContext(com.carefirst.nexus.utils.web.model.ResponseContext responseContext) {
    this.responseContext = responseContext;
    return this;
  }

  /**
   * Get responseContext
   * @return responseContext
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public com.carefirst.nexus.utils.web.model.ResponseContext getResponseContext() {
    return responseContext;
  }

  public void setResponseContext(com.carefirst.nexus.utils.web.model.ResponseContext responseContext) {
    this.responseContext = responseContext;
  }

  public SearchDocumentResponse documentProperties(List<DocumentProperty> documentProperties) {
    this.documentProperties = documentProperties;
    return this;
  }

  public SearchDocumentResponse addDocumentPropertiesItem(DocumentProperty documentPropertiesItem) {
    if (this.documentProperties == null) {
      this.documentProperties = new ArrayList<>();
    }
    this.documentProperties.add(documentPropertiesItem);
    return this;
  }

  /**
   * Get documentProperties
   * @return documentProperties
  */
  @ApiModelProperty(value = "")

  @Valid

  public List<DocumentProperty> getDocumentProperties() {
    return documentProperties;
  }

  public void setDocumentProperties(List<DocumentProperty> documentProperties) {
    this.documentProperties = documentProperties;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SearchDocumentResponse searchDocumentResponse = (SearchDocumentResponse) o;
    return Objects.equals(this.responseContext, searchDocumentResponse.responseContext) &&
        Objects.equals(this.documentProperties, searchDocumentResponse.documentProperties);
  }

  @Override
  public int hashCode() {
    return Objects.hash(responseContext, documentProperties);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SearchDocumentResponse {\n");
    
    sb.append("    responseContext: ").append(toIndentedString(responseContext)).append("\n");
    sb.append("    documentProperties: ").append(toIndentedString(documentProperties)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

