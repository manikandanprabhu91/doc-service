package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AddDocumentResponse
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-26T11:36:03.601-04:00[America/New_York]")

public class AddDocumentResponse   {
  @JsonProperty("responseContext")
  private com.carefirst.nexus.utils.web.model.ResponseContext responseContext;

  @JsonProperty("documentId")
  private String documentId;

  public AddDocumentResponse responseContext(com.carefirst.nexus.utils.web.model.ResponseContext responseContext) {
    this.responseContext = responseContext;
    return this;
  }

  /**
   * Get responseContext
   * @return responseContext
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public com.carefirst.nexus.utils.web.model.ResponseContext getResponseContext() {
    return responseContext;
  }

  public void setResponseContext(com.carefirst.nexus.utils.web.model.ResponseContext responseContext) {
    this.responseContext = responseContext;
  }

  public AddDocumentResponse documentId(String documentId) {
    this.documentId = documentId;
    return this;
  }

  /**
   * document id
   * @return documentId
  */
  @ApiModelProperty(example = "3091EF6F-0100-CF3E-87B8-A8E0A054E45B", value = "document id")


  public String getDocumentId() {
    return documentId;
  }

  public void setDocumentId(String documentId) {
    this.documentId = documentId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AddDocumentResponse addDocumentResponse = (AddDocumentResponse) o;
    return Objects.equals(this.responseContext, addDocumentResponse.responseContext) &&
        Objects.equals(this.documentId, addDocumentResponse.documentId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(responseContext, documentId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AddDocumentResponse {\n");
    
    sb.append("    responseContext: ").append(toIndentedString(responseContext)).append("\n");
    sb.append("    documentId: ").append(toIndentedString(documentId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

