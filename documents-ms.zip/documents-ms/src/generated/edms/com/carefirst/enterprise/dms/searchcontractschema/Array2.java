
package com.carefirst.enterprise.dms.searchcontractschema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}pdpdid"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}productCategory" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}asOfStartDate" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}asOfEndDate" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "pdpdid",
    "productCategory",
    "asOfStartDate",
    "asOfEndDate"
})
@XmlRootElement(name = "array2")
public class Array2 {

    @XmlElement(required = true)
    protected String pdpdid;
    protected String productCategory;
    protected String asOfStartDate;
    protected String asOfEndDate;

    /**
     * Gets the value of the pdpdid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPdpdid() {
        return pdpdid;
    }

    /**
     * Sets the value of the pdpdid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPdpdid(String value) {
        this.pdpdid = value;
    }

    /**
     * Gets the value of the productCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCategory() {
        return productCategory;
    }

    /**
     * Sets the value of the productCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCategory(String value) {
        this.productCategory = value;
    }

    /**
     * Gets the value of the asOfStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsOfStartDate() {
        return asOfStartDate;
    }

    /**
     * Sets the value of the asOfStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsOfStartDate(String value) {
        this.asOfStartDate = value;
    }

    /**
     * Gets the value of the asOfEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAsOfEndDate() {
        return asOfEndDate;
    }

    /**
     * Sets the value of the asOfEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAsOfEndDate(String value) {
        this.asOfEndDate = value;
    }

}
