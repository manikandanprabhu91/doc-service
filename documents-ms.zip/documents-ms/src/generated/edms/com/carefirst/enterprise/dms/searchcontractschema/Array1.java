
package com.carefirst.enterprise.dms.searchcontractschema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}groupID"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}subGroupID"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}packageClass"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}array2" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "groupID",
    "subGroupID",
    "packageClass",
    "array2"
})
@XmlRootElement(name = "array1")
public class Array1 {

    @XmlElement(required = true)
    protected String groupID;
    @XmlElement(required = true)
    protected String subGroupID;
    @XmlElement(required = true)
    protected String packageClass;
    protected Array2 array2;

    /**
     * Gets the value of the groupID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupID() {
        return groupID;
    }

    /**
     * Sets the value of the groupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupID(String value) {
        this.groupID = value;
    }

    /**
     * Gets the value of the subGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubGroupID() {
        return subGroupID;
    }

    /**
     * Sets the value of the subGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubGroupID(String value) {
        this.subGroupID = value;
    }

    /**
     * Gets the value of the packageClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPackageClass() {
        return packageClass;
    }

    /**
     * Sets the value of the packageClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPackageClass(String value) {
        this.packageClass = value;
    }

    /**
     * Gets the value of the array2 property.
     * 
     * @return
     *     possible object is
     *     {@link Array2 }
     *     
     */
    public Array2 getArray2() {
        return array2;
    }

    /**
     * Sets the value of the array2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link Array2 }
     *     
     */
    public void setArray2(Array2 value) {
        this.array2 = value;
    }

}
