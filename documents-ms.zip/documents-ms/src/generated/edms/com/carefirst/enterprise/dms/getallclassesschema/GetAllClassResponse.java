
package com.carefirst.enterprise.dms.getallclassesschema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema}success"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema}subclassList"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema}error" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "success",
    "subclassList",
    "error"
})
@XmlRootElement(name = "GetAllClassResponse")
public class GetAllClassResponse {

    protected boolean success;
    @XmlElement(required = true)
    protected SubclassList subclassList;
    protected Error error;

    /**
     * Gets the value of the success property.
     * 
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * Sets the value of the success property.
     * 
     */
    public void setSuccess(boolean value) {
        this.success = value;
    }

    /**
     * Gets the value of the subclassList property.
     * 
     * @return
     *     possible object is
     *     {@link SubclassList }
     *     
     */
    public SubclassList getSubclassList() {
        return subclassList;
    }

    /**
     * Sets the value of the subclassList property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubclassList }
     *     
     */
    public void setSubclassList(SubclassList value) {
        this.subclassList = value;
    }

    /**
     * Gets the value of the error property.
     * 
     * @return
     *     possible object is
     *     {@link Error }
     *     
     */
    public Error getError() {
        return error;
    }

    /**
     * Sets the value of the error property.
     * 
     * @param value
     *     allowed object is
     *     {@link Error }
     *     
     */
    public void setError(Error value) {
        this.error = value;
    }

}
