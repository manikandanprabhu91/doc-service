
package com.carefirst.enterprise.dms.searchcontractschema;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}success"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}docList" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}bodyResponse" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}error" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "success",
    "docList",
    "bodyResponse",
    "error"
})
@XmlRootElement(name = "SearchContractResponse")
public class SearchContractResponse {

    protected boolean success;
    protected List<DocList> docList;
    protected BodyResponse bodyResponse;
    protected Error error;

    /**
     * Gets the value of the success property.
     * 
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * Sets the value of the success property.
     * 
     */
    public void setSuccess(boolean value) {
        this.success = value;
    }

    /**
     * Gets the value of the docList property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the docList property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDocList().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DocList }
     * 
     * 
     */
    public List<DocList> getDocList() {
        if (docList == null) {
            docList = new ArrayList<DocList>();
        }
        return this.docList;
    }

    /**
     * Gets the value of the bodyResponse property.
     * 
     * @return
     *     possible object is
     *     {@link BodyResponse }
     *     
     */
    public BodyResponse getBodyResponse() {
        return bodyResponse;
    }

    /**
     * Sets the value of the bodyResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link BodyResponse }
     *     
     */
    public void setBodyResponse(BodyResponse value) {
        this.bodyResponse = value;
    }

    /**
     * Gets the value of the error property.
     * 
     * @return
     *     possible object is
     *     {@link Error }
     *     
     */
    public Error getError() {
        return error;
    }

    /**
     * Sets the value of the error property.
     * 
     * @param value
     *     allowed object is
     *     {@link Error }
     *     
     */
    public void setError(Error value) {
        this.error = value;
    }

}
