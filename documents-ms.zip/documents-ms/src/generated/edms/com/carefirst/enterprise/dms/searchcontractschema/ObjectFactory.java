
package com.carefirst.enterprise.dms.searchcontractschema;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.carefirst.enterprise.dms.searchcontractschema package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ContractStatus_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "ContractStatus");
    private final static QName _SenderID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "SenderID");
    private final static QName _SenderApp_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "SenderApp");
    private final static QName _MsgID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "msgID");
    private final static QName _MsgVersion_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "msgVersion");
    private final static QName _Success_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "success");
    private final static QName _Class_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "class");
    private final static QName _GroupID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "groupID");
    private final static QName _SubGroupID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "subGroupID");
    private final static QName _GroupName_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "groupName");
    private final static QName _ProductName_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "productName");
    private final static QName _FilenetName_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "filenetName");
    private final static QName _ProductCategory_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "productCategory");
    private final static QName _EffStartDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "effStartDate");
    private final static QName _EffEndDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "effEndDate");
    private final static QName _PubDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "pubDate");
    private final static QName _Guid_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "guid");
    private final static QName _DocumentName_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "documentName");
    private final static QName _DocumentType_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "documentType");
    private final static QName _DocumentSubType_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "documentSubType");
    private final static QName _Pdpdid_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "pdpdid");
    private final static QName _SubscriberID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "subscriberID");
    private final static QName _MemberSuffix_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "memberSuffix");
    private final static QName _VersionInd_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "versionInd");
    private final static QName _MsgCode_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "msgCode");
    private final static QName _Msg_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "msg");
    private final static QName _PackageClass_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "packageClass");
    private final static QName _AsOfStartDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "asOfStartDate");
    private final static QName _AsOfEndDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "asOfEndDate");
    private final static QName _CurrentInd_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", "currentInd");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.carefirst.enterprise.dms.searchcontractschema
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SearchContractRequest }
     * 
     */
    public SearchContractRequest createSearchContractRequest() {
        return new SearchContractRequest();
    }

    /**
     * Create an instance of {@link Header }
     * 
     */
    public Header createHeader() {
        return new Header();
    }

    /**
     * Create an instance of {@link SearchContractRequest.Body }
     * 
     */
    public SearchContractRequest.Body createSearchContractRequestBody() {
        return new SearchContractRequest.Body();
    }

    /**
     * Create an instance of {@link SearchContractResponse }
     * 
     */
    public SearchContractResponse createSearchContractResponse() {
        return new SearchContractResponse();
    }

    /**
     * Create an instance of {@link DocList }
     * 
     */
    public DocList createDocList() {
        return new DocList();
    }

    /**
     * Create an instance of {@link ArrayResponse1 }
     * 
     */
    public ArrayResponse1 createArrayResponse1() {
        return new ArrayResponse1();
    }

    /**
     * Create an instance of {@link ArrayResponse2 }
     * 
     */
    public ArrayResponse2 createArrayResponse2() {
        return new ArrayResponse2();
    }

    /**
     * Create an instance of {@link BodyResponse }
     * 
     */
    public BodyResponse createBodyResponse() {
        return new BodyResponse();
    }

    /**
     * Create an instance of {@link CriteriaResponse }
     * 
     */
    public CriteriaResponse createCriteriaResponse() {
        return new CriteriaResponse();
    }

    /**
     * Create an instance of {@link Error }
     * 
     */
    public Error createError() {
        return new Error();
    }

    /**
     * Create an instance of {@link Array1 }
     * 
     */
    public Array1 createArray1() {
        return new Array1();
    }

    /**
     * Create an instance of {@link Array2 }
     * 
     */
    public Array2 createArray2() {
        return new Array2();
    }

    /**
     * Create an instance of {@link Classes }
     * 
     */
    public Classes createClasses() {
        return new Classes();
    }

    /**
     * Create an instance of {@link Criteria }
     * 
     */
    public Criteria createCriteria() {
        return new Criteria();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "ContractStatus")
    public JAXBElement<String> createContractStatus(String value) {
        return new JAXBElement<String>(_ContractStatus_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "SenderID")
    public JAXBElement<String> createSenderID(String value) {
        return new JAXBElement<String>(_SenderID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "SenderApp")
    public JAXBElement<String> createSenderApp(String value) {
        return new JAXBElement<String>(_SenderApp_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "msgID")
    public JAXBElement<String> createMsgID(String value) {
        return new JAXBElement<String>(_MsgID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "msgVersion")
    public JAXBElement<String> createMsgVersion(String value) {
        return new JAXBElement<String>(_MsgVersion_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "success")
    public JAXBElement<Boolean> createSuccess(Boolean value) {
        return new JAXBElement<Boolean>(_Success_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "class")
    public JAXBElement<String> createClass(String value) {
        return new JAXBElement<String>(_Class_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "groupID")
    public JAXBElement<String> createGroupID(String value) {
        return new JAXBElement<String>(_GroupID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "subGroupID")
    public JAXBElement<String> createSubGroupID(String value) {
        return new JAXBElement<String>(_SubGroupID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "groupName")
    public JAXBElement<String> createGroupName(String value) {
        return new JAXBElement<String>(_GroupName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "productName")
    public JAXBElement<String> createProductName(String value) {
        return new JAXBElement<String>(_ProductName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "filenetName")
    public JAXBElement<String> createFilenetName(String value) {
        return new JAXBElement<String>(_FilenetName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "productCategory")
    public JAXBElement<String> createProductCategory(String value) {
        return new JAXBElement<String>(_ProductCategory_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "effStartDate")
    public JAXBElement<String> createEffStartDate(String value) {
        return new JAXBElement<String>(_EffStartDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "effEndDate")
    public JAXBElement<String> createEffEndDate(String value) {
        return new JAXBElement<String>(_EffEndDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "pubDate")
    public JAXBElement<String> createPubDate(String value) {
        return new JAXBElement<String>(_PubDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "guid")
    public JAXBElement<String> createGuid(String value) {
        return new JAXBElement<String>(_Guid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "documentName")
    public JAXBElement<String> createDocumentName(String value) {
        return new JAXBElement<String>(_DocumentName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "documentType")
    public JAXBElement<String> createDocumentType(String value) {
        return new JAXBElement<String>(_DocumentType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "documentSubType")
    public JAXBElement<String> createDocumentSubType(String value) {
        return new JAXBElement<String>(_DocumentSubType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "pdpdid")
    public JAXBElement<String> createPdpdid(String value) {
        return new JAXBElement<String>(_Pdpdid_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "subscriberID")
    public JAXBElement<String> createSubscriberID(String value) {
        return new JAXBElement<String>(_SubscriberID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "memberSuffix")
    public JAXBElement<String> createMemberSuffix(String value) {
        return new JAXBElement<String>(_MemberSuffix_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "versionInd")
    public JAXBElement<String> createVersionInd(String value) {
        return new JAXBElement<String>(_VersionInd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "msgCode")
    public JAXBElement<String> createMsgCode(String value) {
        return new JAXBElement<String>(_MsgCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "msg")
    public JAXBElement<String> createMsg(String value) {
        return new JAXBElement<String>(_Msg_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "packageClass")
    public JAXBElement<String> createPackageClass(String value) {
        return new JAXBElement<String>(_PackageClass_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "asOfStartDate")
    public JAXBElement<String> createAsOfStartDate(String value) {
        return new JAXBElement<String>(_AsOfStartDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "asOfEndDate")
    public JAXBElement<String> createAsOfEndDate(String value) {
        return new JAXBElement<String>(_AsOfEndDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchContractSchema", name = "currentInd")
    public JAXBElement<Integer> createCurrentInd(Integer value) {
        return new JAXBElement<Integer>(_CurrentInd_QNAME, Integer.class, null, value);
    }

}
