
package com.carefirst.enterprise.dms.searchschema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}header" minOccurs="0"/&gt;
 *         &lt;element name="body"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}criteria"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}classes"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}versionHistory" minOccurs="0"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}fromDate" minOccurs="0"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}toDate" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "header",
    "body"
})
@XmlRootElement(name = "SearchDocRequest")
public class SearchDocRequest {

    protected Header header;
    @XmlElement(required = true)
    protected SearchDocRequest.Body body;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public void setHeader(Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the body property.
     * 
     * @return
     *     possible object is
     *     {@link SearchDocRequest.Body }
     *     
     */
    public SearchDocRequest.Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchDocRequest.Body }
     *     
     */
    public void setBody(SearchDocRequest.Body value) {
        this.body = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}criteria"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}classes"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}versionHistory" minOccurs="0"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}fromDate" minOccurs="0"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchSchema}toDate" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "criteria",
        "classes",
        "versionHistory",
        "fromDate",
        "toDate"
    })
    public static class Body {

        @XmlElement(required = true)
        protected Criteria criteria;
        @XmlElement(required = true)
        protected Classes classes;
        protected Boolean versionHistory;
        protected String fromDate;
        protected String toDate;

        /**
         * Gets the value of the criteria property.
         * 
         * @return
         *     possible object is
         *     {@link Criteria }
         *     
         */
        public Criteria getCriteria() {
            return criteria;
        }

        /**
         * Sets the value of the criteria property.
         * 
         * @param value
         *     allowed object is
         *     {@link Criteria }
         *     
         */
        public void setCriteria(Criteria value) {
            this.criteria = value;
        }

        /**
         * Gets the value of the classes property.
         * 
         * @return
         *     possible object is
         *     {@link Classes }
         *     
         */
        public Classes getClasses() {
            return classes;
        }

        /**
         * Sets the value of the classes property.
         * 
         * @param value
         *     allowed object is
         *     {@link Classes }
         *     
         */
        public void setClasses(Classes value) {
            this.classes = value;
        }

        /**
         * Gets the value of the versionHistory property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isVersionHistory() {
            return versionHistory;
        }

        /**
         * Sets the value of the versionHistory property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setVersionHistory(Boolean value) {
            this.versionHistory = value;
        }

        /**
         * Gets the value of the fromDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getFromDate() {
            return fromDate;
        }

        /**
         * Sets the value of the fromDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setFromDate(String value) {
            this.fromDate = value;
        }

        /**
         * Gets the value of the toDate property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getToDate() {
            return toDate;
        }

        /**
         * Sets the value of the toDate property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setToDate(String value) {
            this.toDate = value;
        }

    }

}
