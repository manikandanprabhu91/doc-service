@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.carefirst.com/Enterprise/DMS/GetPropSchema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.carefirst.enterprise.dms.getpropschema;
