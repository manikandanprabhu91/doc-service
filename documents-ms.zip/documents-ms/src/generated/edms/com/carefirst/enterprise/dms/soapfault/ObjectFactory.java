
package com.carefirst.enterprise.dms.soapfault;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.carefirst.enterprise.dms.soapfault package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.carefirst.enterprise.dms.soapfault
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Fault }
     * 
     */
    public Fault createFault() {
        return new Fault();
    }

    /**
     * Create an instance of {@link Fault.FaultType }
     * 
     */
    public Fault.FaultType createFaultFaultType() {
        return new Fault.FaultType();
    }

    /**
     * Create an instance of {@link Fault.FaultType.SystemUnavailableFault }
     * 
     */
    public Fault.FaultType.SystemUnavailableFault createFaultFaultTypeSystemUnavailableFault() {
        return new Fault.FaultType.SystemUnavailableFault();
    }

    /**
     * Create an instance of {@link Fault.FaultType.SourceSystemInvalid }
     * 
     */
    public Fault.FaultType.SourceSystemInvalid createFaultFaultTypeSourceSystemInvalid() {
        return new Fault.FaultType.SourceSystemInvalid();
    }

    /**
     * Create an instance of {@link Fault.FaultType.DataNotFound }
     * 
     */
    public Fault.FaultType.DataNotFound createFaultFaultTypeDataNotFound() {
        return new Fault.FaultType.DataNotFound();
    }

    /**
     * Create an instance of {@link Fault.FaultType.ApplicationException }
     * 
     */
    public Fault.FaultType.ApplicationException createFaultFaultTypeApplicationException() {
        return new Fault.FaultType.ApplicationException();
    }

    /**
     * Create an instance of {@link Fault.FaultType.SystemTimeOutException }
     * 
     */
    public Fault.FaultType.SystemTimeOutException createFaultFaultTypeSystemTimeOutException() {
        return new Fault.FaultType.SystemTimeOutException();
    }

    /**
     * Create an instance of {@link Fault.FaultType.PackageNotCompiled }
     * 
     */
    public Fault.FaultType.PackageNotCompiled createFaultFaultTypePackageNotCompiled() {
        return new Fault.FaultType.PackageNotCompiled();
    }

    /**
     * Create an instance of {@link Fault.FaultType.AuthenticationException }
     * 
     */
    public Fault.FaultType.AuthenticationException createFaultFaultTypeAuthenticationException() {
        return new Fault.FaultType.AuthenticationException();
    }

    /**
     * Create an instance of {@link Fault.FaultType.InputDataInvalid }
     * 
     */
    public Fault.FaultType.InputDataInvalid createFaultFaultTypeInputDataInvalid() {
        return new Fault.FaultType.InputDataInvalid();
    }

    /**
     * Create an instance of {@link Fault.FaultType.DefaultFault }
     * 
     */
    public Fault.FaultType.DefaultFault createFaultFaultTypeDefaultFault() {
        return new Fault.FaultType.DefaultFault();
    }

}
