
package com.carefirst.enterprise.dms.addupdatedocschema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}header" minOccurs="0"/&gt;
 *         &lt;element name="body"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}guid"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}docData" minOccurs="0"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}docProp" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "header",
    "body"
})
@XmlRootElement(name = "UpdateDocRequest")
public class UpdateDocRequest {

    protected Header header;
    @XmlElement(required = true)
    protected UpdateDocRequest.Body body;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public void setHeader(Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the body property.
     * 
     * @return
     *     possible object is
     *     {@link UpdateDocRequest.Body }
     *     
     */
    public UpdateDocRequest.Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     * 
     * @param value
     *     allowed object is
     *     {@link UpdateDocRequest.Body }
     *     
     */
    public void setBody(UpdateDocRequest.Body value) {
        this.body = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}guid"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}docData" minOccurs="0"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}docProp" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "guid",
        "docData",
        "docProp"
    })
    public static class Body {

        @XmlElement(required = true)
        protected String guid;
        protected byte[] docData;
        protected DocProp docProp;

        /**
         * Gets the value of the guid property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getGuid() {
            return guid;
        }

        /**
         * Sets the value of the guid property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setGuid(String value) {
            this.guid = value;
        }

        /**
         * Gets the value of the docData property.
         * 
         * @return
         *     possible object is
         *     byte[]
         */
        public byte[] getDocData() {
            return docData;
        }

        /**
         * Sets the value of the docData property.
         * 
         * @param value
         *     allowed object is
         *     byte[]
         */
        public void setDocData(byte[] value) {
            this.docData = value;
        }

        /**
         * Gets the value of the docProp property.
         * 
         * @return
         *     possible object is
         *     {@link DocProp }
         *     
         */
        public DocProp getDocProp() {
            return docProp;
        }

        /**
         * Sets the value of the docProp property.
         * 
         * @param value
         *     allowed object is
         *     {@link DocProp }
         *     
         */
        public void setDocProp(DocProp value) {
            this.docProp = value;
        }

    }

}
