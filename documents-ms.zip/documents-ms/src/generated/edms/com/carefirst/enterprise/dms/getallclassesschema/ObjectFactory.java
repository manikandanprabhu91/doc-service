
package com.carefirst.enterprise.dms.getallclassesschema;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.carefirst.enterprise.dms.getallclassesschema package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Success_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "success");
    private final static QName _SubClass_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "subClass");
    private final static QName _MsgCode_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "msgCode");
    private final static QName _Msg_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "msg");
    private final static QName _SenderID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "senderID");
    private final static QName _SenderApp_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "senderApp");
    private final static QName _MsgVersion_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "msgVersion");
    private final static QName _MsgID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "msgID");
    private final static QName _ClassName_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", "className");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.carefirst.enterprise.dms.getallclassesschema
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetClassRequest }
     * 
     */
    public GetClassRequest createGetClassRequest() {
        return new GetClassRequest();
    }

    /**
     * Create an instance of {@link GetAllClassResponse }
     * 
     */
    public GetAllClassResponse createGetAllClassResponse() {
        return new GetAllClassResponse();
    }

    /**
     * Create an instance of {@link SubclassList }
     * 
     */
    public SubclassList createSubclassList() {
        return new SubclassList();
    }

    /**
     * Create an instance of {@link Error }
     * 
     */
    public Error createError() {
        return new Error();
    }

    /**
     * Create an instance of {@link Header }
     * 
     */
    public Header createHeader() {
        return new Header();
    }

    /**
     * Create an instance of {@link GetClassRequest.Body }
     * 
     */
    public GetClassRequest.Body createGetClassRequestBody() {
        return new GetClassRequest.Body();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "success")
    public JAXBElement<Boolean> createSuccess(Boolean value) {
        return new JAXBElement<Boolean>(_Success_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "subClass")
    public JAXBElement<String> createSubClass(String value) {
        return new JAXBElement<String>(_SubClass_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "msgCode")
    public JAXBElement<String> createMsgCode(String value) {
        return new JAXBElement<String>(_MsgCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "msg")
    public JAXBElement<String> createMsg(String value) {
        return new JAXBElement<String>(_Msg_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "senderID")
    public JAXBElement<String> createSenderID(String value) {
        return new JAXBElement<String>(_SenderID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "senderApp")
    public JAXBElement<String> createSenderApp(String value) {
        return new JAXBElement<String>(_SenderApp_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "msgVersion")
    public JAXBElement<String> createMsgVersion(String value) {
        return new JAXBElement<String>(_MsgVersion_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "msgID")
    public JAXBElement<String> createMsgID(String value) {
        return new JAXBElement<String>(_MsgID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", name = "className")
    public JAXBElement<String> createClassName(String value) {
        return new JAXBElement<String>(_ClassName_QNAME, String.class, null, value);
    }

}
