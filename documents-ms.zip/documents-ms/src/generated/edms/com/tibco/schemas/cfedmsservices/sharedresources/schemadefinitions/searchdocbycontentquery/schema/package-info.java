@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.tibco.schemas.cfedmsservices.sharedresources.schemadefinitions.searchdocbycontentquery.schema;
