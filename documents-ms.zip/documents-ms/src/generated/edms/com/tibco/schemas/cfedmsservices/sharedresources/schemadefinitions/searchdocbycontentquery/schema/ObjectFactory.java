
package com.tibco.schemas.cfedmsservices.sharedresources.schemadefinitions.searchdocbycontentquery.schema;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.tibco.schemas.cfedmsservices.sharedresources.schemadefinitions.searchdocbycontentquery.schema package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SenderID_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "senderID");
    private final static QName _SenderApp_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "senderApp");
    private final static QName _MsgVersion_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "msgVersion");
    private final static QName _MsgID_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "msgID");
    private final static QName _Success_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "success");
    private final static QName _Error_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "error");
    private final static QName _ClassName_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "className");
    private final static QName _JoinClause_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "joinClause");
    private final static QName _MaxRecords_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "maxRecords");
    private final static QName _Options_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "options");
    private final static QName _OrderBy_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "orderBy");
    private final static QName _SelectList_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "selectList");
    private final static QName _SubClass_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "subClass");
    private final static QName _WhereClause_QNAME = new QName("http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", "whereClause");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.tibco.schemas.cfedmsservices.sharedresources.schemadefinitions.searchdocbycontentquery.schema
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SearchDocByContentQueryRequest }
     * 
     */
    public SearchDocByContentQueryRequest createSearchDocByContentQueryRequest() {
        return new SearchDocByContentQueryRequest();
    }

    /**
     * Create an instance of {@link Header }
     * 
     */
    public Header createHeader() {
        return new Header();
    }

    /**
     * Create an instance of {@link SearchDocByContentQueryRequest.Body }
     * 
     */
    public SearchDocByContentQueryRequest.Body createSearchDocByContentQueryRequestBody() {
        return new SearchDocByContentQueryRequest.Body();
    }

    /**
     * Create an instance of {@link SearchDocByContentQueryResponse }
     * 
     */
    public SearchDocByContentQueryResponse createSearchDocByContentQueryResponse() {
        return new SearchDocByContentQueryResponse();
    }

    /**
     * Create an instance of {@link DocList }
     * 
     */
    public DocList createDocList() {
        return new DocList();
    }

    /**
     * Create an instance of {@link DocProperty }
     * 
     */
    public DocProperty createDocProperty() {
        return new DocProperty();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "senderID")
    public JAXBElement<String> createSenderID(String value) {
        return new JAXBElement<String>(_SenderID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "senderApp")
    public JAXBElement<String> createSenderApp(String value) {
        return new JAXBElement<String>(_SenderApp_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "msgVersion")
    public JAXBElement<String> createMsgVersion(String value) {
        return new JAXBElement<String>(_MsgVersion_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "msgID")
    public JAXBElement<String> createMsgID(String value) {
        return new JAXBElement<String>(_MsgID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "success")
    public JAXBElement<Boolean> createSuccess(Boolean value) {
        return new JAXBElement<Boolean>(_Success_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "error")
    public JAXBElement<String> createError(String value) {
        return new JAXBElement<String>(_Error_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "className")
    public JAXBElement<String> createClassName(String value) {
        return new JAXBElement<String>(_ClassName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "joinClause")
    public JAXBElement<String> createJoinClause(String value) {
        return new JAXBElement<String>(_JoinClause_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "maxRecords")
    public JAXBElement<String> createMaxRecords(String value) {
        return new JAXBElement<String>(_MaxRecords_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "options")
    public JAXBElement<String> createOptions(String value) {
        return new JAXBElement<String>(_Options_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "orderBy")
    public JAXBElement<String> createOrderBy(String value) {
        return new JAXBElement<String>(_OrderBy_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "selectList")
    public JAXBElement<String> createSelectList(String value) {
        return new JAXBElement<String>(_SelectList_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "subClass")
    public JAXBElement<Boolean> createSubClass(Boolean value) {
        return new JAXBElement<Boolean>(_SubClass_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd", name = "whereClause")
    public JAXBElement<String> createWhereClause(String value) {
        return new JAXBElement<String>(_WhereClause_QNAME, String.class, null, value);
    }

}
