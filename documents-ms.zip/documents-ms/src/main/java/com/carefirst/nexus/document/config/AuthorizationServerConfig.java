package com.carefirst.nexus.document.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import org.springframework.security.config.http.SessionCreationPolicy;

/**
 * @author aad7740
 *
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class AuthorizationServerConfig extends WebSecurityConfigurerAdapter {

    @Value("${application.security.realm}")
	private String securityRealm;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and().httpBasic()
			.realmName(securityRealm).and().csrf().disable()
			.authorizeRequests()
			.antMatchers("/actuator/**").permitAll()
            .antMatchers("/v1/**").permitAll()
            .anyRequest().authenticated();
        http.headers().frameOptions().sameOrigin();
    }
}
