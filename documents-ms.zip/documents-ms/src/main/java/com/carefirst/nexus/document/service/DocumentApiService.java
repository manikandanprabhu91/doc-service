package com.carefirst.nexus.document.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.carefirst.enterprise.dms.addupdatedocschema.AddDocRequest;
import com.carefirst.enterprise.dms.addupdatedocschema.AddDocResponse;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest.Body;
import com.carefirst.enterprise.dms.getdocschema.GetDocResponse;
import com.carefirst.enterprise.dms.searchcontractschema.Criteria;
import com.carefirst.enterprise.dms.searchcontractschema.SearchContractRequest;
import com.carefirst.enterprise.dms.searchcontractschema.SearchContractResponse;
import com.carefirst.enterprise.dms.searchschema.Classes;
import com.carefirst.enterprise.dms.searchschema.DocList;
import com.carefirst.enterprise.dms.searchschema.DocProperty;
import com.carefirst.enterprise.dms.searchschema.SearchDocRequest;
import com.carefirst.enterprise.dms.searchschema.SearchDocResponse;
import com.carefirst.nexus.document.gen.api.DocumentsApiDelegate;
import com.carefirst.nexus.document.gen.model.AddDocumentResponse;
import com.carefirst.nexus.document.gen.model.ContractDocument;
import com.carefirst.nexus.document.gen.model.ContractDocumentResponse;
import com.carefirst.nexus.document.gen.model.ContractSearchCriteria;
import com.carefirst.nexus.document.gen.model.DocumentDetails;
import com.carefirst.nexus.document.gen.model.DocumentProperty;
import com.carefirst.nexus.document.gen.model.DocumentRequest;
import com.carefirst.nexus.document.gen.model.DocumentResponse;
import com.carefirst.nexus.document.gen.model.ProductCategory;
import com.carefirst.nexus.document.gen.model.SearchDocumentResponse;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.model.ErrorResponseCode;

/**
 * 
 * @author aad7740
 *
 */
@Service
public class DocumentApiService implements DocumentsApiDelegate {

	private static final Logger LOGGER = LogManager.getLogger(DocumentApiService.class);

	@Autowired
	EDMSService edmsService;


	@Override
	public ResponseEntity<AddDocumentResponse> addDocument(DocumentRequest documentRequest) {
		LOGGER.info(">>>>>>>>>>>>>addDocument method Start >>>>>>>>>>>>>>>>>>>>> ");
		AddDocumentResponse addDocumentResponse = new AddDocumentResponse();
		try {
			AddDocRequest docRequest = new AddDocRequest();
			com.carefirst.enterprise.dms.addupdatedocschema.AddDocRequest.Body body = new com.carefirst.enterprise.dms.addupdatedocschema.AddDocRequest.Body();
			body.setDocData(documentRequest.getDocumentData());
			body.setClazz(documentRequest.getDocumentClass());
			com.carefirst.enterprise.dms.addupdatedocschema.DocProp value = new com.carefirst.enterprise.dms.addupdatedocschema.DocProp();
			com.carefirst.enterprise.dms.addupdatedocschema.DocProp.Property documentTitle = new com.carefirst.enterprise.dms.addupdatedocschema.DocProp.Property();
			documentTitle.setPropertyName("DocumentStatus");
			documentTitle.setValue("Approved");
			value.getProperty().add(documentTitle);
			body.setDocProp(value);
			docRequest.setBody(body);
			AddDocResponse docResponse = edmsService.addDocument(docRequest);
			if(docResponse != null) {
				addDocumentResponse.setDocumentId(docResponse.getGuid());
			}
		} catch (Exception e) {
			LOGGER.error(e);
			throw new AppJSONException(ErrorResponseCode.ERROR_UNEXPECTED_ERROR,
					new String[] { "Exception While Adding Documents" });
		}
		LOGGER.info(">>>>>>>>>>>>>addDocument method Start >>>>>>>>>>>>>>>>>>>>> ");
		return new ResponseEntity<>(addDocumentResponse, HttpStatus.OK);
	}



	@Override
	public ResponseEntity<ContractDocumentResponse> findContractDocuments(LocalDate searchStartDate,
			LocalDate searchEndDate, List<String> documentClass, ContractSearchCriteria contractSearchCriteria) {
		LOGGER.info(">>>>>>>>>>>>>findContractDocuments method Start >>>>>>>>>>>>>>>>>>>>> ");
		ContractDocumentResponse contractDocumentResponse = new ContractDocumentResponse();
		try {
			List<ContractDocument> contractDocuments = new ArrayList<>();
			SearchContractRequest contractRequest = new SearchContractRequest();
			com.carefirst.enterprise.dms.searchcontractschema.SearchContractRequest.Body value = new com.carefirst.enterprise.dms.searchcontractschema.SearchContractRequest.Body();
			com.carefirst.enterprise.dms.searchcontractschema.Classes classes = new com.carefirst.enterprise.dms.searchcontractschema.Classes();
			value.setClasses(classes);
			Criteria criteria = new Criteria();
			value.setCriteria(criteria);
			contractRequest.setBody(value);
			SearchContractResponse searchContractResponse = edmsService.searchContract(contractRequest);
			if(searchContractResponse != null) {
				for(com.carefirst.enterprise.dms.searchcontractschema.DocList docList : searchContractResponse.getDocList()) {
					ContractDocument contractDocument = new ContractDocument();
					contractDocument.setContractStatus(docList.getContractStatus());
					contractDocument.setDocumentClass(docList.getClazz());
					contractDocument.setDocumentId(docList.getGuid());
					contractDocument.setDocumentName(docList.getDocumentName());
					contractDocument.setDocumentSubType(docList.getDocumentSubType());
					contractDocument.setDocumentType(docList.getDocumentType());
					contractDocument.setEffectiveStartDate(LocalDate.parse(docList.getEffStartDate()));
					contractDocument.setEffectiveEndDate(LocalDate.parse(docList.getEffEndDate()));
					contractDocument.setGroupId(docList.getGroupID());
					contractDocument.setGroupName(docList.getGroupName());
					contractDocument.setProductCategory(ProductCategory.fromValue(docList.getProductCategory()));
					contractDocument.setProductId(docList.getArrayResponse1().getArrayResponse2().getPdpdid());
					contractDocument.setProductName(docList.getProductName());
					contractDocument.setSubgroupId(docList.getSubGroupID());
					contractDocument.setPublishDate(LocalDate.parse(docList.getPubDate()));
					contractDocuments.add(contractDocument);
				}
			}			
			contractDocumentResponse.setDocumentProperties(contractDocuments);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new AppJSONException(ErrorResponseCode.ERROR_UNEXPECTED_ERROR,
					new String[] { "Exception While finding Contract Documents" });
		}
		LOGGER.info(">>>>>>>>>>>>>findContractDocuments method Start >>>>>>>>>>>>>>>>>>>>> ");
		return new ResponseEntity<>(contractDocumentResponse, HttpStatus.OK);
	}



	@Override
	public ResponseEntity<SearchDocumentResponse> findDocuments(LocalDate searchStartDate, LocalDate searchEndDate,
			List<String> documentClass, Boolean versionHistory, List<DocumentProperty> searchCriteria) {
		LOGGER.info(">>>>>>>>>>>>>findDocuments method Start >>>>>>>>>>>>>>>>>>>>> ");
		SearchDocumentResponse searchDocumentResponse = new SearchDocumentResponse();
		try {
			List<DocumentProperty> documentProperties = new ArrayList<>();
			SearchDocRequest request = new SearchDocRequest();
			com.carefirst.enterprise.dms.searchschema.SearchDocRequest.Body value = new com.carefirst.enterprise.dms.searchschema.SearchDocRequest.Body();
			Classes classes = new Classes();
			value.setClasses(classes);
			com.carefirst.enterprise.dms.searchschema.Criteria criteria = new com.carefirst.enterprise.dms.searchschema.Criteria(); 
			value.setCriteria(criteria);
			value.setFromDate(String.valueOf(searchStartDate));
			value.setToDate(String.valueOf(searchEndDate));
			value.setVersionHistory(versionHistory);
			request.setBody(value);
			SearchDocResponse searchDocResponse = edmsService.searchDocument(request);
			if(searchDocResponse != null) {
				for(DocList docList:searchDocResponse.getDocList()) {
					for(DocProperty docProperty:docList.getDocProperty()){
						DocumentProperty documentProperty = new DocumentProperty();
						documentProperty.setDataType(docProperty.getPropertyDatatype());
						documentProperty.setName(docProperty.getPropertyName());
						documentProperty.setValue(docProperty.getValue());
						documentProperties.add(documentProperty);
					}
				}
			}
			searchDocumentResponse.setDocumentProperties(documentProperties);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new AppJSONException(ErrorResponseCode.ERROR_UNEXPECTED_ERROR,
					new String[] { "Exception While Searching Document Details" });
		}
		LOGGER.info(">>>>>>>>>>>>>findDocuments method Start >>>>>>>>>>>>>>>>>>>>> ");
		return new ResponseEntity<>(searchDocumentResponse, HttpStatus.OK);
	}



	@Override
	public ResponseEntity<DocumentResponse> getDocument(String documentId) {
		LOGGER.info(">>>>>>>>>>>>>getDocument method Start >>>>>>>>>>>>>>>>>>>>> ");
		DocumentResponse documentResponse = new DocumentResponse();
		try {
			GetDocRequest request = new GetDocRequest();
			Body body = new Body();
			body.setGuid(documentId);
			request.setBody(body);
			GetDocResponse docResponse = edmsService.getDocument(request);
			DocumentDetails document = new DocumentDetails();
			if(docResponse != null) {
				document.setDocumentId(document.getDocumentId());
				document.setDocumentMimeType(document.getDocumentMimeType());
				document.setDocumentData(docResponse.getDocData());
				document.setDocumentTitle(docResponse.getDocTitle());
			}
			documentResponse.setDocument(document);
		} catch (Exception e) {
			LOGGER.error(e);
			throw new AppJSONException(ErrorResponseCode.ERROR_UNEXPECTED_ERROR,
					new String[] { "Exception While Retrieving Document Details" });
		}
		LOGGER.info(">>>>>>>>>>>>>getDocument method End >>>>>>>>>>>>>>>>>>>>> ");
		return new ResponseEntity<>(documentResponse, HttpStatus.OK);
	}

}
