package com.carefirst.nexus.document.service;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carefirst.enterprise.dms.addupdatedocschema.AddDocRequest;
import com.carefirst.enterprise.dms.addupdatedocschema.AddDocResponse;
import com.carefirst.enterprise.dms.documentmanagement.DocumentManagementPort;
import com.carefirst.enterprise.dms.documentmanagement.DocumentManagementServiceServiceagent;
import com.carefirst.enterprise.dms.getallclassesschema.GetAllClassResponse;
import com.carefirst.enterprise.dms.getallclassesschema.GetClassRequest;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest;
import com.carefirst.enterprise.dms.getdocschema.GetDocResponse;
import com.carefirst.enterprise.dms.searchcontractschema.SearchContractRequest;
import com.carefirst.enterprise.dms.searchcontractschema.SearchContractResponse;
import com.carefirst.enterprise.dms.searchschema.SearchDocRequest;
import com.carefirst.enterprise.dms.searchschema.SearchDocResponse;
import com.carefirst.nexus.document.config.EDMSConfig;

/**
 * 
 * @author aad7740
 *
 */
@Service
public class EDMSService {

	private static final Logger LOGGER = LogManager.getLogger(EDMSService.class);

	private final EDMSConfig properties;

	@Autowired
	public EDMSService(EDMSConfig properties) {
		this.properties = properties;
	}


	public GetAllClassResponse getAllClasses(GetClassRequest request) {
		GetAllClassResponse getAllClassResponse = null;
		try {
			DocumentManagementPort documentManagementPort = getDocumentManagementPort();
			getAllClassResponse = documentManagementPort.getAllClasses(request);
		} catch (Exception e) {
			LOGGER.error("Error Occuring getDocument Service >>>>>>>>>>>> ", e.getMessage());
		}
		return getAllClassResponse;
	}

	public GetDocResponse getDocument(GetDocRequest request) {
		GetDocResponse getDocResponse = null;
		try {
			DocumentManagementPort documentManagementPort = getDocumentManagementPort();
			getDocResponse = documentManagementPort.getDocument(request);
		} catch (Exception e) {
			LOGGER.error("Error Occuring getDocument Service >>>>>>>>>>>> ", e.getMessage());
		}
		return getDocResponse;
	}

	public AddDocResponse addDocument(AddDocRequest request) {
		AddDocResponse addDocResponse = null;
		try {
			DocumentManagementPort documentManagementPort = getDocumentManagementPort();
			addDocResponse = documentManagementPort.addDocument(request);
		} catch (Exception e) {
			LOGGER.error("Error Occuring searchContract Service >>>>>>>>>>>> ", e.getMessage());
		}
		return addDocResponse;
	}

	public SearchContractResponse searchContract(SearchContractRequest request) {
		SearchContractResponse searchContractResponse = null;
		try {
			DocumentManagementPort documentManagementPort = getDocumentManagementPort();
			searchContractResponse = documentManagementPort.searchContract(request);
		} catch (Exception e) {
			LOGGER.error("Error Occuring searchContract Service >>>>>>>>>>>> ", e.getMessage());
		}
		return searchContractResponse;
	}

	public SearchDocResponse searchDocument(SearchDocRequest request) {
		SearchDocResponse searchDocResponse = null;
		try {
			DocumentManagementPort documentManagementPort = getDocumentManagementPort();
			searchDocResponse = documentManagementPort.searchDocument(request);
		} catch (Exception e) {
			LOGGER.error("Error Occuring searchDocument Service >>>>>>>>>>>> ", e.getMessage());
		}
		return searchDocResponse;
	}


	public DocumentManagementPort getDocumentManagementPort() {
		DocumentManagementPort documentManagementPort = null;
		LOGGER.info(">>>> getDocumentManagementPort method Start >>>>>>>>>>");
		try {
			QName qName = new QName("http://www.carefirst.com/Enterprise/DMS/DocumentManagement", "DocumentManagementService.serviceagent");
			URL wsdlurl = new URL("http://sita.gwservices.carefirst.com/dac/edms/v1?wsdl");
			DocumentManagementServiceServiceagent ds = new DocumentManagementServiceServiceagent(wsdlurl, qName);
			documentManagementPort = ds.getDocumentManagementPortEndpoint();
			BindingProvider bp = (BindingProvider) documentManagementPort;
			bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, properties.getEndPoint());
			bp.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, properties.getUsername());
			bp.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, properties.getPassword());
		} catch (Exception e) {
			LOGGER.error("Invalid service configuration");
		}

		return documentManagementPort;
	}

}
